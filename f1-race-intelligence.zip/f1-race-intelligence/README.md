# Formula 1 Race Intelligence Dashboard (Tableau)

An interactive Tableau dashboard and story analysing **6,464 race records across 17 seasons** of Formula 1: driver performance, championship trajectories, tyre strategy, DNF/reliability patterns and podium achievements.

> **Demo:** _add your Tableau Public link here_
> **Video walkthrough:** _add your demo link here_

## Business scenarios
| # | Persona | Goal |
|---|---------|------|
| 1 | F1 Team Performance Strategist | Benchmark points trajectory vs Red Bull and Mercedes, analyse tyre strategy by circuit, find the strongest talent pools |
| 2 | Motorsport Broadcast Analyst | Driver Performance Leaderboard, Grand Prix hosting by country, podium distributions |
| 3 | F1 Technical Regulation Analyst | DNF patterns by failure type and team, reliability scores across seasons |

Details: [docs/scenarios.md](docs/scenarios.md)

## Repository structure
```
f1-race-intelligence/
├── README.md
├── data/
│   ├── f1_race_data_sample.csv   # SAMPLE data (synthetic) - replace with the real dataset
│   └── data_dictionary.md
├── docs/
│   ├── scenarios.md
│   ├── project_plan.md           # 8 epics / tasks
│   ├── calculated_fields.md
│   ├── worksheets.md
│   ├── dashboard_story_guide.md
│   └── performance_testing.md
├── tableau/                      # put your .twbx here
└── screenshots/                  # dashboard screenshots
```

## Tech stack
Tableau Desktop / Tableau Public, CSV/Excel (Google Drive or SQL source).

## How to run
1. Clone the repo.
2. Open Tableau and connect to `data/f1_race_data_sample.csv` (or your real dataset with the same columns).
3. Build the workbook following [docs/calculated_fields.md](docs/calculated_fields.md) and [docs/worksheets.md](docs/worksheets.md), then save it in `tableau/`.
4. Publish to Tableau Public and paste the link above.

## Important note on data
The included CSV is **synthetic sample data** generated to match the expected schema and row count (6,464). It does **not** reflect real F1 results. Swap in your actual dataset before drawing conclusions.

## Author
_Your name_ - Skillwallet project: Data Analytics with Tableau
