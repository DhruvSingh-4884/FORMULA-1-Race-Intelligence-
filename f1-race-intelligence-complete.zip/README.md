# Formula 1 Race Intelligence Dashboard

An interactive data analytics project based on the project plan and worksheet specifications in `docs/`.

> **Data integrity:** `data/f1_race_data_sample.csv` contains 6,464 synthetic sample records. It is schema-matched demonstration data and does not represent actual Formula 1 results. Do not report its chart values as sporting facts. Replace it with a verified dataset before drawing conclusions.

## Project contents

- `dashboard.html` — eight interactive analytical views, four KPI cards, Season/Constructor/Driver/Tyre filters, Top N leaderboard control, five story scenes, and a full synthetic data notice.
- `data/` — sample data and data dictionary.
- `docs/` — project plan, business scenarios, calculated fields, worksheet specs, story guide, and performance checklist.
- `demo_walkthrough.md` — a ready-to-record end-to-end presentation script.
- `tableau/` — reserved for the Tableau workbook. Tableau workbook creation and publishing are not included in this package.

## View the dashboard

From this directory run:

```powershell
python -m http.server 8000
```

Open `http://localhost:8000/dashboard.html`. The browser must load the CSV over HTTP; direct `file://` opening will block the data request.

## Analytical views

1. Championship points trajectory by season and leading constructors
2. Tyre compound vs. mean finishing position by circuit
3. Driver nationality talent pool by sample points
4. Driver performance leaderboard with Top N control
5. Grand Prix rounds by country
6. Podium distribution by driver and constructor
7. Non-finish categories by constructor
8. Finish-rate trend by season

The four KPI cards report filtered sample entries, seasons, constructors, and podium entries. Dashboard filters update all views.

## GitHub Pages

The project can be hosted as a static site after the repository contains the project files. Enable Pages for the `main` branch and repository root, then use the generated URL as the demo link. A Pages deployment was not configured as part of this local package.

## Reproducibility

Calculated field definitions and build instructions are in `docs/calculated_fields.md`, `docs/worksheets.md`, and `docs/dashboard_story_guide.md`. The Tableau workbook location is `tableau/`.
