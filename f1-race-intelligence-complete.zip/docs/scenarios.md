# Scenarios
## Scenario 1: F1 Team Performance Strategist
Senior strategist at a mid-tier constructor. Needs to benchmark championship points trajectory against Red Bull Racing and Mercedes, evaluate how tyre compounds (Soft, Medium, Hard, Intermediate) affect results across circuits, and identify the strongest driver/nationality talent pools.

## Scenario 2: Motorsport Broadcast Analyst
Data journalist preparing pre/post-race content. Needs the Driver Performance Leaderboard (cumulative points across seasons), countries hosting the most Grand Prix rounds, and podium distribution by driver and team.

## Scenario 3: F1 Technical Regulation Analyst
FIA compliance analyst studying DNF patterns: are failure types (engine, brakes, collisions, mechanical) concentrated in particular teams or circuits? Have regulation changes improved completion rates across 17 seasons? Uses the Driver Reliability Analysis stacked bar chart.
