# Dashboard & Story Guide
**Dashboard:** 1200x800 fixed size. Top row KPIs (Races, Podiums, DNF %). Filters: Season, Constructor, Driver, Tyre Compound. Use filter actions between sheets.

**Story points**
1. Overview: leaderboard and KPIs
2. Scenario 1: points trajectory and tyre strategy
3. Scenario 2: hosting countries and podium distribution
4. Scenario 3: DNF patterns and reliability trend
5. Conclusions and recommendations
