# Tableau Calculated Fields
```
// DNF Flag
IF [Status] = "Finished" THEN 0 ELSE 1 END

// Podium Flag
IF [Final Position] <= 3 AND [Status] = "Finished" THEN 1 ELSE 0 END

// Win Flag
IF [Final Position] = 1 AND [Status] = "Finished" THEN 1 ELSE 0 END

// Cumulative Points (table calc; compute along Season)
RUNNING_SUM(SUM([Points]))

// Reliability Score
1 - SUM([DNF Flag]) / COUNT([Driver])

// Positions Gained
[Grid] - [Final Position]

// Failure Type (DNF only)
IF [DNF Flag] = 1 THEN [Status] END

// Focus Teams (benchmark highlight)
IF [Constructor] = "Red Bull Racing" OR [Constructor] = "Mercedes" THEN [Constructor] ELSE "Others" END
```
