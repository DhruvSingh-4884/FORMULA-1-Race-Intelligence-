# Worksheets
| # | Scenario | Worksheet | Chart | Build notes |
|---|---|---|---|---|
| 1 | 1 | Championship Points Trajectory | Line | Season on Columns, Cumulative Points on Rows, colour by Constructor |
| 2 | 1 | Tyre Compound vs Finishing Position | Heatmap | Circuit x Tyre Compound, colour = AVG(Final Position) |
| 3 | 1 | Driver Nationality Talent Pool | Filled map / bar | Nationality, SUM(Points), Podium count |
| 4 | 2 | Driver Performance Leaderboard | Bar/line | Cumulative points by Driver, Top N filter |
| 5 | 2 | GP Rounds by Country | Map/bar | Count of distinct Season+Round by Country |
| 6 | 2 | Podium Distribution | Treemap/stacked bar | SUM(Podium Flag) by Driver and Constructor |
| 7 | 3 | Driver Reliability Analysis | Stacked bar | Constructor x Failure Type, SUM(DNF Flag) |
| 8 | 3 | Reliability Score by Season | Line | Reliability Score over Season, annotate regulation-change years |
