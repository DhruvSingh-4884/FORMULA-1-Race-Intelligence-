# Project Plan (8 Epics)
| # | Epic | Key tasks |
|---|------|-----------|
| 1 | Data Collection & Extraction | Connect to source, verify 6,464 rows and 17 seasons |
| 2 | Data Preparation | Clean nulls/duplicates, standardise team names, create calculated fields |
| 3 | Data Visualization | Build 8 worksheets (see worksheets.md) |
| 4 | Dashboard | Assemble sheets, add Season/Constructor/Driver filters and actions |
| 5 | Story | 4-5 story points following the scenarios |
| 6 | Performance Testing | Extracts, filter tuning, load-time checks |
| 7 | Web Integration | Publish to Tableau Public/Cloud, embed |
| 8 | Demonstration & Documentation | Demo video, README, GitHub push |
