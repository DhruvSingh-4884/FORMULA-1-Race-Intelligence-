# Performance Testing Checklist
- [ ] Use Extract instead of Live connection
- [ ] Hide unused fields; aggregate extract
- [ ] Limit quick filters
- [ ] Use fixed dashboard size
- [ ] Record dashboard load time (Performance Recorder): ____ s
- [ ] Test on Chrome, Edge, Safari
