# Project validation and constraints

## Data inspection performed
- 6,464 records and 12 columns were read from the repository CSV.
- Fields: Season, Round, Circuit, Country, Driver, Driver Nationality, Constructor, Grid, Final Position, Points, Status, Tyre Compound.
- Repository documentation identifies this data as synthetic. Every report and dashboard labels it as synthetic sample data.

## Dashboard coverage
The dashboard has eight views matching `docs/worksheets.md`, four KPI cards, global filters for Season, Constructor, Driver and Tyre Compound, a Top N control, and five story scenes. The CSV is loaded locally by the browser over HTTP.

## Tableau boundary
The archive contains no `.twb` or `.twbx` workbook. Tableau authoring and Tableau Public publishing require Tableau Desktop/Creator access, which is not available in this environment. The Tableau directory remains a documented handoff location; no fabricated published link is claimed.

## Performance checklist
Use Tableau Performance Recorder after rebuilding the workbook. Record first-load and filter response times on Chrome, Edge, and Safari. Hide unused fields, prefer an extract where appropriate, and limit quick filters as described in `performance_testing.md`.
