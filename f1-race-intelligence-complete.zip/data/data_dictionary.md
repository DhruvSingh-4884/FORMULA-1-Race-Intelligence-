# Data Dictionary
| Field | Type | Description |
|---|---|---|
| Season | Integer | Year (17 seasons) |
| Round | Integer | Race number in season |
| Circuit | String | Track name |
| Country | String | Grand Prix host country |
| Driver | String | Driver name |
| Driver Nationality | String | Driver's nationality |
| Constructor | String | Team |
| Grid | Integer | Starting position |
| Final Position | Integer | Classified/finishing order |
| Points | Integer | Championship points scored |
| Status | String | Finished, Engine, Brakes, Collision, Mechanical |
| Tyre Compound | String | Soft, Medium, Hard, Intermediate |
