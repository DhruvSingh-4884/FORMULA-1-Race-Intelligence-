# End-to-end walkthrough script (5–7 minutes)

## 0:00 — Introduction
Introduce Formula 1 Race Intelligence and the three audiences: a constructor strategist, a motorsport broadcaster, and a technical reliability analyst. State clearly that the included 6,464 rows are synthetic sample data for demonstrating the workflow, not historical results.

## 0:40 — Problem and data
Explain the analytical questions: compare points trajectories, explore tyre compounds, find nationality and country patterns, understand podium distribution, and inspect non-finish categories. Show the field dictionary and describe validation of season, round, points, position, status, and compound fields.

## 1:30 — Dashboard controls and KPIs
Open `dashboard.html` in a browser through the local HTTP server. Demonstrate the Season, Constructor, Driver, Tyre Compound, and Top N controls. Explain that the KPI values recalculate with the filters.

## 2:10 — Strategy and broadcast views
Walk through the points trajectory, tyre/finish heatmap, nationality talent pool, leaderboard, rounds by country, and podium bubbles. Read the synthetic-data notice before interpreting any values.

## 3:50 — Reliability views
Show the constructor/failure-category comparison and seasonal finish-rate line. Explain the formulas and that any conclusions must be rerun on verified race data.

## 4:40 — Story scenes and conclusions
Move through all five story scenes: Overview, Strategist view, Broadcast view, Reliability view, Conclusions. Summarize what each view helps an analyst investigate, without stating sample results as facts.

## 5:30 — Tableau and next steps
Show the Tableau worksheet specifications, calculated fields, dashboard guide, and performance checklist. Note that the actual Tableau workbook and Tableau Public link must be completed in Tableau Desktop with a verified dataset. Close by showing the repository and data replacement instructions.
